package resource.retrieval;

import java.util.HashMap;

public class DfWord {
    public HashMap<String,Integer> df;
    public DfWord(HashMap<String,Integer> df){
        this.df=df;
    }
}
