package resource.retrieval;

import java.util.List;

public class MaxTf {
    public List<Integer> max_tf;
    MaxTf(List<Integer> max_tf){
        this.max_tf = max_tf;
    }
}
