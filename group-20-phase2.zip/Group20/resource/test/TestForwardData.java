package resource.test;

import resource.spider.Crawler;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import resource.forward.CreateForward;
import resource.forward.ForwardData;

public class TestForwardData {
    public static void main(String[] arg) {
        // List<String> title = new ArrayList<>();
        // List<String> content = new ArrayList<>();
        // title.add("Hello world play play with me");
        // content.add("Hello will you play entertainment");
        // try {
        // HashMap<Integer,ForwardData> test = CreateForward.forwardIndex(title,
        // content);
        // for(int i=0;i<title.size();i++){
        // ForwardData temp = test.get(i);
        // temp.print();
        // }
        // } catch (IOException e) {
        // // TODO Auto-generated catch block
        // e.printStackTrace();
        // }
    }
}
